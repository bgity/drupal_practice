# Welcome to your CDA Site Repo!

**(C.D.A.) Stands for Cloud Drupal Admin.** We'll be listing some guidelines and tips to help you here in this README. We needed a name and QComm IT's marketing department was busy. Presently it's built with NodeJS, Angular and MongoDB using and making available, the Amazon SDK. We pronounce it: See-Da.

**Remember these basics as you develop:** 

* [**Don't hack core**](https://www.drupal.org/best-practices/do-not-hack-core), even if you do it will not make it out to the servers, ADA will simply replace it with her own clean, QCOM MSB compliant core.

![image](http://www.jeffgeerling.com/sites/jeffgeerling.com/files/hack-core-kill-a-kitten.jpg)
  
* **sites/default/settings.php** is available for editing for your local only! Same applies as rule above (It will get replaced on deployment.) 

* The master branch is for production releases. *(Still in discussion, we may add a branch called prod OR enable the use of tags OR make it a config option.)* You will be able to release from your nonprod branch into your nonprod Amazon webserver at any time (you can override this to whatever branch you would like to release from through the CDA admin.)

* The nonprod branch is for your nonprod environment releases. You will be able to release from your nonprod branch into your nonprod Amazon webserver at any time (you can override this to whatever branch you would like to release from through the CDA admin.)
  
* You will be notified in the CDA when there is a new Core update available and how to either merge it in the CDA interface OR do it by hand locally in your repo.
  
* While speaking about what we talked about in the previous comment... it would be great if you would go ahead and issue this command immediately after cloning to your local (this gives you the ability to fetch and merge new core updates from your BU's authoritative Drupal core repo.):  
 
`git remote add upstream https://github.qualcomm.com/casdrupalaws/drupal7.git`

* Later, when a new update for core comes in you can simply:  

`git fetch upstream`

* Then merge this into whatever branch you are in: (check `git status` to see which branch you are in (you are given master and nonprod.)) (Our 7.x-1.x branch will always have the latest release.)

`git merge upstream/7.x-1.x`

* Send the merged, updated files back up to github:

`git push origin <whatever-your-branch-name-is>`

* You may notice that you have sites/all/modules/contrib and sites/all/modules/custom folder. Contrib is to be used from any modules maintained by the Drupal.org community as a whole and Drush will respect it as such as far as `drush dl` and other drush module related commands. Custom is to be used for your own custom self written non community contributed modules (often site specific.)
  
* You may also notice that you have a module in sites/all/modules called registry_rebuild. This is a helper module for the drush module. This is where drush wants it. If you'd like to read more on Registry Rebuild look here: [**THE REGISTRY REBUILD MOULE**](https://www.drupal.org/project/registry_rebuild)

* To use drush to maintain your libraries, modules and themes we highly advise using `drush dl` vs `drush up`. This plays much better with git commits.

* Again, To merge at anytime simply verify what branch you are in:  
`git status` and for example let's say we are in nonprod, but we want to merge into master, we want to be in the branch we want to merge changes into not where the changes are coming from so we would:  
`git checkout master` and then merge in changes:  
`git merge nonprod`

* For more help and documentation on how to use these CDA repos please see your corresponding github.qualcomm.com wiki.









